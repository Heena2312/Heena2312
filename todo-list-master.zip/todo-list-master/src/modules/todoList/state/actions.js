export default {
  addItem: 'ADD_ITEM',
  removeItem: 'REMOVE_ITEM',
  searchList: 'SEARCH_LIST',
  markItemComplete: 'MARK_ITEM_COMPLETE',
  markItemIncomplete: 'MARK_ITEM_INCOMPLETE',
  goToNextPage: 'GO_TO_NEXT_PAGE',
  goToPreviousPage: 'GO_TO_PREVIOUS_PAGE',
};
