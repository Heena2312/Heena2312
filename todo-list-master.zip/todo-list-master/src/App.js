import {ToDoListPage} from './modules/todoList';

import './App.css';

function App() {
  return (
    <div className="App">
      <ToDoListPage />
    </div>
  );
}

export default App;
